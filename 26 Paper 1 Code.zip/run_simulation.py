#!/usr/bin/env python3
"""Run every experiment and write CSV files plus summary.md.   Usage: python run_simulation.py [--quick] [--out results]"""
import argparse, copy, os, time
import numpy as np, pandas as pd, yaml
from wormhole_sim import quantum, experiments as ex


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--config', default='config.yaml'); ap.add_argument('--out', default='results'); ap.add_argument('--quick', action='store_true')
    a = ap.parse_args()
    cfg = yaml.safe_load(open(a.config))
    if a.quick:
        cfg['experiments']['repetitions'] = 2; cfg['experiments']['n_updates'] = 800; cfg['experiments']['quantum_calibration_shots'] = 3000
    os.makedirs(a.out, exist_ok=True)
    t0 = time.time()
    grid, table, src = quantum.calibrate(cfg)
    pd.DataFrame({'pair_fidelity': grid, 'bit_error_simulated': table, 'bit_error_theory_2(1-F)/3': quantum.analytic_bit_error(grid)}).to_csv(a.out + '/quantum_calibration.csv', index=False)
    gap = float(np.max(np.abs(table - quantum.analytic_bit_error(grid))))
    print('quantum calibration source: %s | max |simulated - theory| bit error = %.4f' % (src, gap))
    if src == 'qiskit-aer':
        assert gap < (0.03 if a.quick else 0.012), 'Qiskit teleportation circuit disagrees with the Werner-state theory'
    pbit = quantum.make_pbit(grid, table)
    out = {}
    for name, fn in [('latency_vs_update_size', ex.exp_latency_vs_size), ('latency_vs_distance', ex.exp_latency_vs_distance),
                     ('tail_latency', ex.exp_tail), ('wan_traffic', ex.exp_traffic), ('entanglement_vs_noise', ex.exp_entanglement_vs_noise),
                     ('fidelity_over_time', ex.exp_fidelity_time), ('scalability', ex.exp_scalability), ('ablation', ex.exp_ablation)]:
        out[name] = fn(cfg, pbit); out[name].to_csv('%s/%s.csv' % (a.out, name), index=False); print('done', name, '(%.0fs)' % (time.time() - t0))
    write_summary(cfg, out, a.out, src)


def red(base, new): return 100.0 * (base - new) / base


def write_summary(cfg, out, d, src):
    s = out['latency_vs_update_size']; g = lambda df, col, **k: df[(df.method == k['m']) & (df[k['x'][0]] == k['x'][1])][col].iloc[0]
    L = []
    L.append('# Simulation summary (auto-generated)\n\nAll numbers are produced by this code with the assumptions in config.yaml; quantum source: %s.\n' % src)
    for sz in (5000, 5000000):
        cw = g(s, 'mean_ms', m='CWAN', x=('update_size_bytes', sz)); pr = g(s, 'mean_ms', m='Proposed', x=('update_size_bytes', sz)); cc = g(s, 'mean_ms', m='CCERT', x=('update_size_bytes', sz))
        tf = g(s, 'teleport_fraction', m='Proposed', x=('update_size_bytes', sz))
        L.append('- Update size %s: CWAN %.1f ms, Proposed %.1f ms (%.1f%% vs CWAN), classical-certificate baseline CCERT %.1f ms; teleported fraction %.0f%%.' % ('%d KB' % (sz // 1000) if sz < 1e6 else '%d MB' % (sz // 1e6), cw, pr, red(cw, pr), cc, 100 * tf))
    t = out['wan_traffic']
    tot = t.pivot(index='scenario', columns='method', values='total_wan_GB'); dec = t.pivot(index='scenario', columns='method', values='decision_path_GB')
    chg = [100.0 * (tot.loc[i, 'Proposed'] - tot.loc[i, 'CWAN']) / tot.loc[i, 'CWAN'] for i in tot.index]
    L.append('- Total WAN traffic, Proposed vs CWAN: %+.3f%% to %+.3f%% across scenarios (bulk data still travels over the classical WAN).' % (min(chg), max(chg)))
    L.append('- Decision-path WAN traffic, Proposed vs CWAN: %.1f%% to %.1f%% reduction.' % (min(red(dec.loc[i, 'CWAN'], dec.loc[i, 'Proposed']) for i in dec.index), max(red(dec.loc[i, 'CWAN'], dec.loc[i, 'Proposed']) for i in dec.index)))
    ab = out['ablation']; L.append('- Ablation (mixed scenario): undetected incorrect reconstructions per run: ' + ', '.join('%s=%.2f' % (r.configuration, r.undetected_incorrect_per_run) for r in ab.itertuples()))
    en = out['entanglement_vs_noise']; L.append('- Forced teleportation, success rate from %.1f%% (F=%.2f) to %.1f%% (F=%.2f).' % (en.success_rate_pct.iloc[0], en.pair_fidelity.iloc[0], en.success_rate_pct.iloc[-1], en.pair_fidelity.iloc[-1]))
    open(d + '/summary.md', 'w').write('\n'.join(L) + '\n'); print('\n'.join(L))


if __name__ == '__main__':
    main()
