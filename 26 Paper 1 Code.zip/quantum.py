"""Quantum part: teleportation through a noisy (Werner) Bell pair, simulated with Qiskit Aer.

A Bell pair of fidelity F is produced by applying a 2-qubit depolarizing channel of strength
lam = 4(1-F)/3 to |Phi+>. A computational-basis bit is teleported and read at the receiver.
Theory for a Werner pair: bit-error probability = 2(1-F)/3.
"""
import numpy as np


def analytic_bit_error(F):
    return 2.0 * (1.0 - np.asarray(F, float)) / 3.0


def qiskit_bit_error(F, shots=20000, seed=7):
    from qiskit import QuantumCircuit
    from qiskit_aer import AerSimulator
    from qiskit_aer.noise import depolarizing_error
    lam = min(1.0, 4.0 * (1.0 - F) / 3.0)
    errs = []
    for bit in (0, 1):
        qc = QuantumCircuit(3, 1)
        if bit:
            qc.x(0)                      # state to teleport: |bit>
        qc.h(1); qc.cx(1, 2)             # Bell pair on qubits 1,2
        if lam > 0:
            qc.append(depolarizing_error(lam, 2).to_instruction(), [1, 2])
        qc.cx(0, 1); qc.h(0)             # Bell-state measurement basis change at the sender
        qc.cx(1, 2); qc.cz(0, 2)         # Pauli corrections (deferred-measurement form)
        qc.measure(2, 0)                 # receiver reads the bit
        counts = AerSimulator(seed_simulator=seed + bit).run(qc, shots=shots).result().get_counts()
        errs.append(counts.get(str(1 - bit), 0) / shots)
    return float(np.mean(errs))


def calibrate(cfg):
    """Return (grid, p_bit_table, source). Uses Qiskit if enabled and importable."""
    grid = np.round(np.arange(0.70, 1.0001, 0.02), 4)
    if cfg['quantum'].get('use_qiskit', True):
        try:
            shots = cfg['experiments']['quantum_calibration_shots']
            return grid, np.array([qiskit_bit_error(F, shots) for F in grid]), 'qiskit-aer'
        except Exception as e:  # pragma: no cover
            print('WARNING: Qiskit unavailable (%s); using analytic Werner-state formula.' % e)
    return grid, analytic_bit_error(grid), 'analytic'


def make_pbit(grid, table):
    return lambda F: float(np.interp(F, grid, table))
