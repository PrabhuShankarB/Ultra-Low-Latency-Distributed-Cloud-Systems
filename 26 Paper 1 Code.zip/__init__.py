"""Hybrid classical-quantum coordination simulator (QEDU / QTRU / QAFSM)."""
