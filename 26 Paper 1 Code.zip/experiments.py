"""Experiments. Each function returns a pandas DataFrame; run_simulation.py writes them to CSV."""
import copy, math, zlib
import numpy as np
import pandas as pd
from scipy import stats
from .simulator import (make_workload, make_draws, classical_latencies, run_proposed, q_pairs, ctl_bytes)

METHODS = ['CWAN', 'BACO', 'LBGR', 'HCOF', 'QUHC', 'CCERT', 'Proposed']


def ci95(x):
    x = np.asarray(x, float)
    return 0.0 if len(x) < 2 else float(stats.t.ppf(0.975, len(x) - 1) * x.std(ddof=1) / math.sqrt(len(x)))


def scenario(cfg, name, **over):
    sc = dict(cfg['scenarios'][name]); sc.update(over)
    sc.setdefault('horizon', cfg['experiments']['n_updates'] / sc['rate'])
    return sc


def simulate(cfg, sc, seed, pbit, **flags):
    rng = np.random.default_rng(seed)
    wl = make_workload(rng, cfg, sc)
    d = make_draws(rng, wl.t.size)
    lat = classical_latencies(wl, d, cfg)
    prop = run_proposed(wl, d, cfg, rng, pbit, lat['CWAN'], **flags)
    lat['Proposed'] = prop['latency']
    return wl, lat, prop


def seeds(cfg, tag):
    base = cfg['seed'] + (zlib.crc32(tag.encode()) % 100000) * 7   # deterministic across runs
    return [base + 1000 * r for r in range(cfg['experiments']['repetitions'])]


def traffic(wl, cfg, prop):
    S = wl.S_bits / 8.0; tot = S.sum() / 1e9; cb = ctl_bytes(cfg); n = S.size; m = cfg['methods']
    res = {k: (tot, tot) for k in ('CWAN', 'BACO', 'HCOF')}
    res['LBGR'] = (tot * m['lbgr_traffic_factor'],) * 2
    res['QUHC'] = (tot * m['quhc_traffic_factor'],) * 2
    res['CCERT'] = (tot + n * cb / 1e9, n * cb / 1e9)
    ntel = prop['attempted'].sum()
    done = prop['ok'] | prop['undet']
    res['Proposed'] = (tot + ntel * cb / 1e9, (ntel * cb + S[~done].sum()) / 1e9)
    return res


def _rows(x_name, xs, per_x):
    rows = []
    for x, per_method in zip(xs, per_x):
        for mth in METHODS:
            v = per_method[mth]
            rows.append({x_name: x, 'method': mth, 'mean_ms': np.mean(v), 'ci95_ms': ci95(v)})
    return rows


def exp_latency_vs_size(cfg, pbit):
    sizes = [5e3, 1e4, 2.5e4, 5e4, 1e5, 2.5e5, 5e5, 1e6, 2e6, 5e6]
    rows = []
    for s in sizes:
        sc = scenario(cfg, cfg['experiments']['default_scenario'], size='fixed', size_bytes=s)
        per = {m: [] for m in METHODS}; frac = []
        for sd in seeds(cfg, 'size%d' % s):
            wl, lat, prop = simulate(cfg, sc, sd, pbit)
            for m in METHODS: per[m].append(lat[m].mean())
            frac.append(prop['attempted'].mean())
        for m in METHODS:
            rows.append({'update_size_bytes': int(s), 'method': m, 'mean_ms': np.mean(per[m]), 'ci95_ms': ci95(per[m]),
                         'teleport_fraction': np.mean(frac) if m == 'Proposed' else np.nan})
    return pd.DataFrame(rows)


def exp_latency_vs_distance(cfg, pbit):
    dists = [100, 300, 500, 800, 1000, 1500, 2000, 3000, 4000, 5000]
    rows = []
    for dk in dists:
        sc = scenario(cfg, cfg['experiments']['default_scenario'], size='fixed', size_bytes=cfg['experiments']['default_size_bytes'], dist_km=dk)
        per = {m: [] for m in METHODS}
        for sd in seeds(cfg, 'dist%d' % dk):
            wl, lat, prop = simulate(cfg, sc, sd, pbit)
            for m in METHODS: per[m].append(lat[m].mean())
        for m in METHODS:
            rows.append({'distance_km': dk, 'method': m, 'mean_ms': np.mean(per[m]), 'ci95_ms': ci95(per[m])})
    return pd.DataFrame(rows)


def exp_tail(cfg, pbit):
    rows = []
    for name in ('bursty', 'congested', 'mixed'):
        sc = scenario(cfg, name)
        p95 = {m: [] for m in METHODS}; p99 = {m: [] for m in METHODS}
        for sd in seeds(cfg, 'tail' + name):
            wl, lat, prop = simulate(cfg, sc, sd, pbit)
            for m in METHODS:
                p95[m].append(np.percentile(lat[m], 95)); p99[m].append(np.percentile(lat[m], 99))
        for m in METHODS:
            rows.append({'scenario': name, 'method': m, 'p95_ms': np.mean(p95[m]), 'p95_ci95': ci95(p95[m]),
                         'p99_ms': np.mean(p99[m]), 'p99_ci95': ci95(p99[m])})
    return pd.DataFrame(rows)


def exp_traffic(cfg, pbit):
    rows = []
    for name in ('low', 'moderate', 'high', 'bursty', 'congested', 'long_distance', 'large_payloads', 'mixed'):
        sc = scenario(cfg, name)
        acc = {m: ([], []) for m in METHODS}
        for sd in seeds(cfg, 'traf' + name):
            wl, lat, prop = simulate(cfg, sc, sd, pbit)
            for m, (t, dp) in traffic(wl, cfg, prop).items():
                acc[m][0].append(t); acc[m][1].append(dp)
        for m in METHODS:
            rows.append({'scenario': name, 'method': m, 'total_wan_GB': np.mean(acc[m][0]), 'total_ci95': ci95(acc[m][0]),
                         'decision_path_GB': np.mean(acc[m][1]), 'decision_ci95': ci95(acc[m][1])})
    return pd.DataFrame(rows)


def exp_entanglement_vs_noise(cfg, pbit):
    """Characterisation run: teleportation is forced and QAFSM gating is off, so that the
    behaviour below F_min can be observed."""
    q = q_pairs(cfg); rows = []
    for F in [0.98, 0.96, 0.93, 0.91, 0.90, 0.88, 0.86, 0.84, 0.82, 0.80]:
        sc = scenario(cfg, cfg['experiments']['default_scenario'], fidelity=F, size='fixed', size_bytes=cfg['experiments']['default_size_bytes'])
        util, succ, detf, und = [], [], [], 0
        for sd in seeds(cfg, 'ent%.2f' % F):
            wl, lat, prop = simulate(cfg, sc, sd, pbit, force=True, qafsm=False)
            att = prop['attempted'].sum()
            util.append(prop['pairs_used_ok'] / max(1, prop['pairs_generated']))
            succ.append(prop['ok'].sum() / max(1, att)); detf.append(prop['det_fail'].sum() / max(1, att))
            und += int(prop['undet'].sum())
        rows.append({'pair_fidelity': F, 'entanglement_utilization_pct': 100 * np.mean(util), 'success_rate_pct': 100 * np.mean(succ),
                     'detected_failure_pct': 100 * np.mean(detf), 'undetected_incorrect_total': und,
                     'theory_success_pct': 100 * (1 - pbit(F)) ** q})
    return pd.DataFrame(rows)


def exp_fidelity_time(cfg, pbit):
    rows = []
    for gate in (True, False):
        for sd in seeds(cfg, 'fid')[:1]:
            sc = scenario(cfg, cfg['experiments']['default_scenario'], rate=10, horizon=500, fidelity=[0.97, 0.82], size='fixed', size_bytes=cfg['experiments']['default_size_bytes'])
            wl, lat, prop = simulate(cfg, sc, sd, pbit, qafsm=gate)
            for i in range(10):
                m = (wl.t >= 50 * i) & (wl.t < 50 * (i + 1))
                att = prop['attempted'][m]
                rows.append({'qafsm_enabled': gate, 'interval_s': '%d-%d' % (50 * i, 50 * i + 50), 'mean_fidelity': wl.F[m].mean(),
                             'teleport_fraction': att.mean(), 'undetected_incorrect': int(prop['undet'][m].sum()),
                             'detected_failures': int(prop['det_fail'][m].sum()), 'mean_latency_ms': lat['Proposed'][m].mean()})
    return pd.DataFrame(rows)


def exp_scalability(cfg, pbit):
    rows = []; sl = cfg['scaling']
    for N in [5, 8, 10, 12, 15, 18, 20, 22, 25, 30]:
        c2 = copy.deepcopy(cfg)
        c2['methods']['lbgr_path_stretch'] += sl['lbgr_stretch_slope_per_region'] * (N - 5)
        base = cfg['scenarios'][cfg['experiments']['default_scenario']]['rho']
        sc = scenario(c2, cfg['experiments']['default_scenario'], rho=min(0.9, base + sl['rho_slope_per_region'] * (N - 5)),
                      size='fixed', size_bytes=cfg['experiments']['default_size_bytes'])
        per = {m: [] for m in METHODS}
        for sd in seeds(cfg, 'scale%d' % N):
            wl, lat, prop = simulate(c2, sc, sd, pbit)
            for m in METHODS: per[m].append(lat[m].mean())
        for m in METHODS:
            rows.append({'regions': N, 'method': m, 'mean_ms': np.mean(per[m]), 'ci95_ms': ci95(per[m])})
    return pd.DataFrame(rows)


def exp_ablation(cfg, pbit):
    configs = {'Full framework': {}, 'Without QAFSM': dict(qafsm=False), 'Without QEDU': dict(qedu=False), 'Without QTRU': dict(qtru=False)}
    rows = []
    for name, fl in configs.items():
        sc = scenario(cfg, 'mixed', fidelity=[0.96, 0.88], size='loguniform')
        a = {k: [] for k in ('avg', 'p99', 'tot', 'dec', 'und', 'det', 'tel')}
        for sd in seeds(cfg, 'abl'):
            wl, lat, prop = simulate(cfg, sc, sd, pbit, **fl)
            a['avg'].append(lat['Proposed'].mean()); a['p99'].append(np.percentile(lat['Proposed'], 99))
            t, dp = traffic(wl, cfg, prop)['Proposed']; a['tot'].append(t); a['dec'].append(dp)
            a['und'].append(prop['undet'].sum()); a['det'].append(prop['det_fail'].sum()); a['tel'].append(prop['attempted'].mean())
        rows.append({'configuration': name, 'avg_latency_ms': np.mean(a['avg']), 'avg_ci95': ci95(a['avg']), 'p99_latency_ms': np.mean(a['p99']),
                     'total_wan_GB': np.mean(a['tot']), 'decision_path_GB': np.mean(a['dec']), 'undetected_incorrect_per_run': np.mean(a['und']),
                     'detected_failures_per_run': np.mean(a['det']), 'teleport_fraction': np.mean(a['tel'])})
    return pd.DataFrame(rows)
