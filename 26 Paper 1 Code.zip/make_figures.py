#!/usr/bin/env python3
"""Redraw the paper's result figures from results/*.csv.   Usage: python make_figures.py [results_dir] [figures_dir]"""
import os, sys
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

R = sys.argv[1] if len(sys.argv) > 1 else 'results'
O = sys.argv[2] if len(sys.argv) > 2 else 'figures'
os.makedirs(O, exist_ok=True)
plt.rcParams.update({'font.family': 'serif', 'font.size': 7, 'mathtext.fontset': 'stix', 'axes.linewidth': 0.5,
                     'legend.fontsize': 5.8, 'savefig.dpi': 600})
M = ['CWAN', 'BACO', 'LBGR', 'HCOF', 'QUHC', 'CCERT', 'Proposed']
ST = {'CWAN': dict(color='#1f1f1f', marker='o', ls='-'), 'BACO': dict(color='#6b6b6b', marker='s', ls='--'),
      'LBGR': dict(color='#9a9a9a', marker='^', ls='-.'), 'HCOF': dict(color='#4a4a4a', marker='D', ls=':'),
      'QUHC': dict(color='#8a8a8a', marker='v', ls='--'), 'CCERT': dict(color='#1f4e9c', marker='x', ls='-'),
      'Proposed': dict(color='#c00000', marker='*', ls='-', lw=1.4, ms=4.5)}
LAB = {'CCERT': 'CCERT (classical certificate)'}


def lines(df, x, y, xlabel, ylabel, name, logx=False, ci=None):
    fig, ax = plt.subplots(figsize=(3.45, 2.3))
    for m in M:
        d = df[df.method == m].sort_values(x)
        s = dict(lw=0.8, ms=2.6); s.update(ST[m])
        ax.plot(d[x], d[y], label=LAB.get(m, m), **s)
        if ci:
            ax.fill_between(d[x], d[y] - d[ci], d[y] + d[ci], color=ST[m]['color'], alpha=0.15, lw=0)
    if logx: ax.set_xscale('log')
    ax.set_xlabel(xlabel); ax.set_ylabel(ylabel); ax.grid(True, lw=0.3, alpha=0.5)
    ax.legend(ncol=2, frameon=True, framealpha=0.9, edgecolor='#999999', loc='upper left', borderpad=0.3, labelspacing=0.25)
    fig.tight_layout(pad=0.3); fig.savefig('%s/%s.png' % (O, name)); plt.close(fig)


s = pd.read_csv(R + '/latency_vs_update_size.csv'); s['KB'] = s.update_size_bytes / 1000
lines(s, 'KB', 'mean_ms', 'Update size (KB, log scale)', 'Coordination-decision latency (ms)', 'fig4_latency_vs_size', logx=True, ci='ci95_ms')
d = pd.read_csv(R + '/latency_vs_distance.csv')
lines(d, 'distance_km', 'mean_ms', 'Inter-region distance (km)', 'Coordination-decision latency (ms)', 'fig5_latency_vs_distance', ci='ci95_ms')
sc = pd.read_csv(R + '/scalability.csv')
lines(sc, 'regions', 'mean_ms', 'Number of cloud regions', 'Average latency (ms)', 'fig10_scalability', ci='ci95_ms')

# tail latency (grouped bars)
t = pd.read_csv(R + '/tail_latency.csv'); fig, ax = plt.subplots(figsize=(3.45, 2.4)); scn = ['bursty', 'congested', 'mixed']
groups = [(a, p) for a in scn for p in ('p95_ms', 'p99_ms')]; xs = np.arange(len(groups)); w = 0.115
for i, m in enumerate(M):
    vals = [t[(t.scenario == a) & (t.method == m)][p].iloc[0] for a, p in groups]
    ax.bar(xs + (i - 3) * w, vals, w, label=LAB.get(m, m), color=ST[m]['color'], alpha=0.85, edgecolor='black', linewidth=0.3)
ax.set_xticks(xs); ax.set_xticklabels(['%s\n%s' % (a.capitalize(), p[:3].upper()) for a, p in groups], fontsize=6)
ax.set_ylim(0, 1.45 * t[['p95_ms', 'p99_ms']].values.max()); ax.set_ylabel('Tail latency (ms)'); ax.grid(True, axis='y', lw=0.3, alpha=0.5); ax.set_axisbelow(True)
ax.legend(ncol=3, frameon=True, framealpha=0.9, edgecolor='#999999', loc='upper left', fontsize=5.4)
fig.tight_layout(pad=0.3); fig.savefig(O + '/fig6_tail_latency.png'); plt.close(fig)

# WAN traffic on the decision path
w_ = pd.read_csv(R + '/wan_traffic.csv'); fig, ax = plt.subplots(figsize=(3.45, 2.3)); order = list(dict.fromkeys(w_.scenario))
for m in M:
    v = [w_[(w_.scenario == a) & (w_.method == m)].decision_path_GB.iloc[0] for a in order]
    z = dict(lw=0.8, ms=2.6); z.update(ST[m]); ax.plot(range(len(order)), v, label=LAB.get(m, m), **z)
ax.set_xticks(range(len(order))); ax.set_xticklabels([a.replace('_', ' ') for a in order], rotation=30, ha='right', fontsize=6)
ax.set_ylabel('Decision-path WAN traffic (GB)'); ax.grid(True, lw=0.3, alpha=0.5)
ax.legend(ncol=2, frameon=True, framealpha=0.9, edgecolor='#999999', loc='upper left')
fig.tight_layout(pad=0.3); fig.savefig(O + '/fig7_wan_decision_path.png'); plt.close(fig)

# entanglement utilisation / success vs fidelity
e = pd.read_csv(R + '/entanglement_vs_noise.csv'); fig, ax = plt.subplots(figsize=(3.45, 2.3))
ax.plot(e.pair_fidelity, e.success_rate_pct, 'o-', color='#c00000', lw=0.9, ms=2.6, label='Teleportation success (simulated)')
ax.plot(e.pair_fidelity, e.theory_success_pct, 'k--', lw=0.8, label='Theory $(1-2(1-F)/3)^q$')
ax.plot(e.pair_fidelity, e.entanglement_utilization_pct, 's-', color='#1f1f1f', lw=0.9, ms=2.6, label='Entanglement utilization')
ax.axvline(0.90, color='gray', ls=':', lw=0.8); ax.invert_xaxis()
ax.set_xlabel('Entangled-pair fidelity $F$'); ax.set_ylabel('Percentage (%)'); ax.grid(True, lw=0.3, alpha=0.5)
ax.legend(frameon=True, framealpha=0.9, edgecolor='#999999', loc='upper right')
fig.tight_layout(pad=0.3); fig.savefig(O + '/fig8_entanglement_vs_fidelity.png'); plt.close(fig)

# fidelity over time with QAFSM
f = pd.read_csv(R + '/fidelity_over_time.csv'); f = f[f.qafsm_enabled == True].reset_index(drop=True)
mid = [25 + 50 * i for i in range(len(f))]; fig, ax = plt.subplots(figsize=(3.45, 2.3))
ax.plot(mid, f.mean_fidelity, 'o-', color='#1f1f1f', lw=0.9, ms=2.6, label='Mean fidelity')
ax.axhline(0.90, color='#c00000', ls='--', lw=0.8, label='$F_{min}$ = 0.90')
ax.set_xlabel('Time (s)'); ax.set_ylabel('Mean fidelity $F_{ij}$'); ax.grid(True, lw=0.3, alpha=0.4)
a2 = ax.twinx(); a2.bar(mid, 100 * f.teleport_fraction, width=40, color='#c00000', alpha=0.18, label='Updates teleported (%)')
a2.set_ylabel('Updates teleported (%)'); a2.set_ylim(0, 110)
h1, l1 = ax.get_legend_handles_labels(); h2, l2 = a2.get_legend_handles_labels()
ax.legend(h1 + h2, l1 + l2, frameon=True, framealpha=0.9, edgecolor='#999999', loc='lower left')
fig.tight_layout(pad=0.3); fig.savefig(O + '/fig9_fidelity_over_time.png'); plt.close(fig)
print('figures written to', O, sorted(os.listdir(O)))
