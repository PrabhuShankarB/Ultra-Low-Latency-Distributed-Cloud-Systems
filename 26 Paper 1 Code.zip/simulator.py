"""Workload generation, classical baselines and the proposed QEDU + QTRU + QAFSM logic."""
import math
from dataclasses import dataclass
import numpy as np


@dataclass
class Workload:
    t: np.ndarray          # arrival times (s)
    S_bits: np.ndarray     # update payload sizes (bits)
    rho: np.ndarray        # WAN utilisation seen by each update
    L_ms: float            # one-way propagation delay (ms)
    F: np.ndarray          # true entanglement fidelity at each update
    dist_km: float
    horizon: float


@dataclass
class Draws:
    e1: np.ndarray    # Exp(1): data-path queuing
    e2: np.ndarray    # Exp(1): control-path queuing
    u_hit: np.ndarray
    u_crc: np.ndarray
    u_bits: np.ndarray
    f_noise: np.ndarray


def one_way_ms(dist_km, link):
    return dist_km * link['route_factor'] / link['fiber_speed_km_s'] * 1000.0


def cert_bits(cfg):
    return cfg['quantum']['cert_data_bits'] + cfg['quantum']['cert_crc_bits']


def q_pairs(cfg):
    return int(math.ceil(cert_bits(cfg) / cfg['quantum']['bits_per_qubit']))


def ctl_bytes(cfg):
    """Classical bytes sent for one teleported certificate: header + 2 bits per qubit."""
    return cfg['quantum']['header_bytes'] + math.ceil(2 * q_pairs(cfg) / 8)


def make_workload(rng, cfg, sc):
    link, bcfg = cfg['link'], cfg['burst']
    a, horizon = sc['rate'], sc['horizon']
    slots = max(1, int(math.ceil(horizon)))
    if sc.get('burst'):
        p_on, k_on = bcfg['p_on'], bcfg['on_factor']
        r_off = a * (1 - p_on * k_on) / (1 - p_on)
        on = rng.random(slots) < p_on
        rates = np.where(on, a * k_on, r_off)
    else:
        on = np.zeros(slots, bool)
        rates = np.full(slots, float(a))
    counts = rng.poisson(rates)
    if counts.sum() < 10:
        counts[:] = 10
    slot_idx = np.repeat(np.arange(slots), counts)
    t = np.sort(slot_idx + rng.random(slot_idx.size))
    slot = np.minimum(t.astype(int), slots - 1)
    n = t.size
    rho = np.clip(sc['rho'] + np.where(on[slot], bcfg['rho_boost'], 0.0), 0.02, 0.95)
    kind = sc.get('size', 'loguniform')
    if kind == 'fixed':
        S = np.full(n, sc['size_bytes'], float)
    elif kind == 'large':
        S = np.clip(rng.lognormal(math.log(2e6), 0.8, n), 1e5, 2e7)
    else:
        S = np.exp(rng.uniform(math.log(5e3), math.log(5e6), n))
    f = sc['fidelity']
    if isinstance(f, (list, tuple)):          # linear ramp [F_start, F_end] over the horizon
        base = f[0] + (f[1] - f[0]) * np.clip(t / horizon, 0, 1)
    else:
        base = np.full(n, float(f))
    F = np.clip(base + rng.normal(0, cfg['quantum']['fidelity_jitter'], n), 0.5, 1.0)
    return Workload(t, S * 8.0, rho, one_way_ms(sc['dist_km'], link), F, sc['dist_km'], horizon)


def make_draws(rng, n):
    return Draws(rng.exponential(1, n), rng.exponential(1, n), rng.random(n), rng.random(n),
                 rng.random(n), rng.normal(0, 1, n))


def data_delay_mean(wl, cfg):
    return cfg['link']['queue_scale_ms'] * wl.rho / (1 - wl.rho)


def ctl_delay_mean(wl, cfg):
    return cfg['link']['ctl_floor_ms'] + cfg['methods']['ctl_priority_factor'] * data_delay_mean(wl, cfg)


def classical_latencies(wl, d, cfg):
    """Coordination-decision latency (ms) of the classical baselines.
    Baselines wait for the full update (Eq. 1); CCERT is an extra baseline that sends only the
    small certificate over the classical network."""
    link, m = cfg['link'], cfg['methods']
    cap = link['capacity_bps']
    Beff = cap * (1 - wl.rho)
    dm = data_delay_mean(wl, cfg)
    tx = wl.S_bits / Beff * 1000.0
    L = wl.L_ms
    out = {}
    out['CWAN'] = L + tx + d.e1 * dm
    out['BACO'] = L + tx / m['baco_bw_gain'] + d.e1 * dm * m['baco_queue_factor']
    out['LBGR'] = L * m['lbgr_path_stretch'] + m['lbgr_leader_ms'] + tx + d.e1 * dm
    hit = d.u_hit < m['hcof_hit_prob']
    out['HCOF'] = np.where(hit, L + d.e1 * dm * m['hcof_queue_factor'], L + tx + d.e1 * dm * m['hcof_queue_factor'])
    out['QUHC'] = out['CWAN'] + m['quhc_overhead_ms']
    cb = ctl_bytes(cfg) * 8.0
    out['CCERT'] = L + cb / Beff * 1000.0 + cfg['link']['ctl_floor_ms'] + d.e2 * m['ctl_priority_factor'] * dm
    return out


def run_proposed(wl, d, cfg, rng, pbit, lat_cwan, qedu=True, qafsm=True, qtru=True, force=False):
    """Event loop for the proposed framework (QEDU provisioning, QTRU selection, QAFSM gating)."""
    qc = cfg['quantum']
    n_up = wl.t.size
    q = q_pairs(cfg)
    dm_all = data_delay_mean(wl, cfg)
    cm_all = ctl_delay_mean(wl, cfg)
    Beff_all = cfg['link']['capacity_bps'] * (1 - wl.rho)
    L = wl.L_ms
    lat = lat_cwan.copy()
    tel = np.zeros(n_up, bool); ok = np.zeros(n_up, bool)
    det_fail = np.zeros(n_up, bool); undet = np.zeros(n_up, bool)
    if not qtru:
        return dict(latency=lat, attempted=tel, ok=ok, det_fail=det_fail, undet=undet,
                    pairs_generated=0, pairs_used_ok=0, pairs_used_total=0, pairs_expired=0)
    lam = qc['lam_init'] if qedu else qc['fixed_lambda_no_qedu']
    n = int(qc['pool_init']); cap = qc['pool_cap']; Tc = qc['coherence_time_s']
    alpha, dts = qc['alpha'], qc['sched_dt_s']
    gen_total = expired = used_total = used_ok = 0
    last_t = 0.0; sched_last = 0.0; next_sched = dts; cnt = 0
    fobs = wl.F + d.f_noise * qc['f_measure_sigma']
    crc_miss = 2.0 ** (-qc['cert_crc_bits'])
    for k in range(n_up):
        t = wl.t[k]; dt = t - last_t
        if dt > 0:
            n_after = int(rng.binomial(n, math.exp(-dt / Tc)))
            expired += n - n_after
            g = int(rng.poisson(lam * dt)); gen_total += g
            n = min(cap, n_after + g)
        last_t = t; cnt += 1
        if qedu and t >= next_sched:
            interval = t - sched_last
            D = q * cnt * (dts / interval) if interval > 0 else 0.0
            E_req = alpha * D; E_av = lam * dts
            if E_av < E_req:
                lam = min(qc['lam_max'], E_req / dts)
            elif E_av > 3 * E_req:
                lam = max(qc['lam_min'], lam * 0.9)
            cnt = 0; sched_last = t; next_sched = t + dts
        Fok = (fobs[k] >= qc['f_min']) if qafsm else True
        wait_est = max(0, q - n) / lam * 1000.0
        T_wh_est = wait_est + L + cm_all[k] + qc['proc_ms']
        T_cls_est = L + wl.S_bits[k] / Beff_all[k] * 1000.0 + dm_all[k]
        if force or (Fok and T_wh_est < T_cls_est):
            tel[k] = True
            if n >= q:
                wait = 0.0; n -= q
            else:
                wait = float(rng.gamma(q - n, 1.0 / lam)) * 1000.0; n = 0
            t_att = wait + L + cfg['link']['ctl_floor_ms'] + d.e2[k] * cfg['methods']['ctl_priority_factor'] * dm_all[k] + qc['proc_ms']
            n_err = int(rng.binomial(q, pbit(wl.F[k])))
            used_total += q
            if n_err == 0:
                ok[k] = True; used_ok += q; lat[k] = t_att
            elif d.u_crc[k] < crc_miss:           # corruption not caught by the integrity check
                undet[k] = True; lat[k] = t_att
            else:                                  # corruption detected -> classical fallback
                det_fail[k] = True; lat[k] = t_att + lat_cwan[k]
    return dict(latency=lat, attempted=tel, ok=ok, det_fail=det_fail, undet=undet,
                pairs_generated=gen_total, pairs_used_ok=used_ok, pairs_used_total=used_total, pairs_expired=expired)
