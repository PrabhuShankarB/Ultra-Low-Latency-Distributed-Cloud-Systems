# Simulation summary (auto-generated)

All numbers are produced by this code with the assumptions in config.yaml; quantum source: qiskit-aer.

- Update size 5 KB: CWAN 7.7 ms, Proposed 9.6 ms (-24.2% vs CWAN), classical-certificate baseline CCERT 7.3 ms; teleported fraction 100%.
- Update size 5 MB: CWAN 74.3 ms, Proposed 27.8 ms (62.6% vs CWAN), classical-certificate baseline CCERT 7.3 ms; teleported fraction 100%.
- Total WAN traffic, Proposed vs CWAN: +0.002% to +0.009% across scenarios (bulk data still travels over the classical WAN).
- Decision-path WAN traffic, Proposed vs CWAN: 71.7% to 73.8% reduction.
- Ablation (mixed scenario): undetected incorrect reconstructions per run: Full framework=6.60, Without QAFSM=8.00, Without QEDU=2.80, Without QTRU=0.00
- Forced teleportation, success rate from 80.9% (F=0.98) to 10.3% (F=0.80).
