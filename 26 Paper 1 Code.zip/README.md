# Hybrid classical-quantum coordination simulator (QEDU / QTRU / QAFSM)

Simulation code for "An Intelligent Entanglement-Assisted Coordination Framework for Ultra-Low-Latency Distributed Cloud Systems".

## Run
    pip install -r requirements.txt
    python run_simulation.py            # full run (about 10-20 s), writes results/*.csv and results/summary.md
    python run_simulation.py --quick    # smoke test

All parameters are in `config.yaml`. Seeds are fixed (derived with zlib.crc32), so two runs give identical CSV files.

## What is simulated
* `wormhole_sim/quantum.py` - a Qiskit Aer teleportation circuit through a Bell pair degraded by a 2-qubit depolarizing channel
  (pair fidelity F). The simulated bit-error rate is checked against the Werner-state result 2(1-F)/3 on every run.
* `wormhole_sim/simulator.py` - workload (Poisson or bursty arrivals, payload sizes), the classical latency model
  T = L + S/B_eff + delta (Eq. 1), and the proposed framework:
  * **QEDU** - entanglement pool with generation rate lambda, decoherence, and demand-driven rate control (Eqs. 14-15).
  * **QTRU** - per-update choice between teleportation (T_wh = q/lambda + L + delta_c, Eq. 2) and classical transfer (Eqs. 12-13).
  * **QAFSM** - teleportation disabled when the observed fidelity is below F_min.
  * The certificate carries an integrity check (CRC). A detected failure falls back to classical transfer; an undetected one is counted as an incorrect reconstruction.
* `wormhole_sim/experiments.py` - latency vs update size and distance, tail latency, WAN traffic, entanglement vs noise, fidelity over time, scalability, ablation.

## Baselines
CWAN, BACO, LBGR, HCOF and QUHC are **simplified models of the baseline families** (their parameters are in `config.yaml`), not
implementations of the cited systems. CCERT is an extra baseline that sends the same small certificate over the classical network.

## Assumptions and limitations (read before citing any number)
* Every parameter is an assumption of the simulator author; none is measured on real hardware or a real WAN.
* WAN utilisation (rho) is an exogenous parameter. Scalability results depend on the assumed contention slope in `config.yaml`.
* Teleportation is simulated one bit per qubit with no error correction or purification; a certificate of q qubits succeeds with probability (1 - 2(1-F)/3)^q.
* Results are produced by this code only. They are not the values printed in earlier manuscript drafts.

## Output files (results/)
latency_vs_update_size.csv, latency_vs_distance.csv, tail_latency.csv, wan_traffic.csv, entanglement_vs_noise.csv,
fidelity_over_time.csv, scalability.csv, ablation.csv, quantum_calibration.csv, summary.md.
